###this script should be in the folder scriptsCoNiTi
 module purge
 module load python/3

scriptsFolder=$PWD
cp /fslhome/glh43/enumlib/trunk/enum.x .
cd ..

workDir=$PWD
echo "working folder is " $workDir


############ preparing for VASP runnings #######################################
mkdir 1_scfVasp
cd 1_scfVasp/
scfDir=$PWD

for i in {1..3}
do

  if [ $i -eq 1 ]
  then
    cd $scfDir
    mkdir bcc ; cd bcc/
  elif [ $i == 2 ]
  then
    cd $scfDir
    mkdir fcc ; cd fcc
  elif [ $i == 3 ]
  then
    cd $scfDir
    mkdir hcp ; cd hcp
  fi

  cp $scriptsFolder/structEnumForBccFccHcp/bcc/struct_enum.in .
  cp $scriptsFolder/CARS/* .
  cp $scriptsFolder/enum.x .
  cp $scriptsFolder/makeStr.py .
  cp $scriptsFolder/prepareForVASP.py .
  cp $scriptsFolder/vaspPotcars/Co/POTCAR Co_POTCAR
  cp $scriptsFolder/vaspPotcars/Ni/POTCAR Ni_POTCAR
  cp $scriptsFolder/vaspPotcars/Ti/POTCAR Ti_POTCAR
  cp $scriptsFolder/getKPoints .
  mkdir toRunVasp
  
  echo "running python..."
  python3 prepareForVASP.py
  # This will generate POSCAR, POTCAR, and myJob files in each folder

done

################## Submitting to queue #########################################

file="folderNames.txt"

for i in {1..3}
do
  if [ $i == 1 ]
  then
    cd $workDir/1_scfVasp/bcc/
    myPath=$PWD
  elif [ $i == 2 ]
  then
    cd $workDir/1_scfVasp/fcc/
    myPath=$PWD
  elif [ $i == 3 ]
  then
    cd $workDir/1_scfVasp/hcp/
    myPath=$PWD
  fi

  while IFS= read -r line
  do
    cd $myPath/toRunVasp/$line
    #sbatch myJob
  done <"$file"

done

################################################################################

