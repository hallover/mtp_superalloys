### this works with python3, as it uses print(something, end="")

import random
import sys
import os
from random import randint
import re  # Python regular expressions module
import numpy as np

#*******************************************************************************
# This function reads a file and stores the lines in the array "lines"
#*******************************************************************************
def getLines(fileName):
    # store the entire file in lines[]
    lines = [] #Declare an empty list named "lines"

    with open (fileName, 'rt') as f:  # Open file for reading.
        for line in f: # Store each line in a string variable "line"
            lines.append(line)  #add that line to our list of lines.

    return lines;

#*******************************************************************************
# This function returns the index of the head of structures data.
#*******************************************************************************
def getHeadIndex(lines, size):
    wordToSearch = "#tot"
    for i in range(0, size - 1):
        if wordToSearch in lines[i]:
                print("I found the line containing ", wordToSearch)   ## <<<<<<<<<<<<<<<<<<<<<<<< tuve que comentar para que funcione con python2.6
                iHead = i
                return iHead; # stop when the head is found!

#*******************************************************************************
# This function returns a new array made up of the elements of the array "lines"
#*******************************************************************************
def getRandomLines(lines, size, nRandomSamples, iHead):
    randomLines = [] #Declare an empty list named "randomLines"
    iLast       = size - 1
    iFirst      = iHead + 1
    maxSamples  = iLast - iFirst + 1

    # to avoid repetition of samples in the randomly chose,
    # we must make sure there are enough lines
    if nRandomSamples < maxSamples :
        randomIndexes = random.sample( range(iFirst, iLast), nRandomSamples)
        for i in randomIndexes:
            print("Line ", i + 1, " is taken from file.")
            newLine = lines[i]
            randomLines.append(newLine)  #add that line to our list of lines.
    else:
        print("nRandom > number of Samples. Stopping...")
        return;

    # save the random lines into a file
    file = open("randomLines.txt","w")
#   Remember that range(0,n) will produce 0, 1, 2,..., n-1
    for i in range(0, nRandomSamples):
        print(randomLines[i], end = '')
        file.write(randomLines[i])
    file.close()

    #uses numpy as np
    # extract the first column of the "randomLines.txt"
    file = np.loadtxt("randomLines.txt")
    first_row = file[:,0]
    # second_row = file[:,1]

    # the first column is converted into an array of integers
    indexLines = []   # declaring array of size 0 in python
    for i in range(0, nRandomSamples):
        indexLines.append( int(first_row[i]) )


    print(indexLines)
    return indexLines; #array of integers

#*******************************************************************************
# this function chooses 200 structures randomly
#*******************************************************************************
def chooseRandom(fileName, nRandomSamples):
    print("choosing  structures randomly...")

    lines = getLines(fileName) # it is an array of lines from the file fileName.
    size  = len(lines)
    iHead = getHeadIndex(lines, size)
    indexLines = getRandomLines(lines, size, nRandomSamples, iHead)

    #print(indexLines)

    return indexLines;

#*******************************************************************************
# this function joins POTCARs of Co,Ni,Ti as asked by vasp file (it could be Co, Ti !!!)
#*******************************************************************************
def getPOTCAR(vaspFile):
    Co_POTCAR_file = "Co_POTCAR "
    Ni_POTCAR_file = "Ni_POTCAR "
    Ti_POTCAR_file = "Ti_POTCAR "

    # print(vaspFile)
    readFile = open(vaspFile)
    lines    = readFile.readlines()
    readFile.close()

    elements = [x.strip() for x in lines[0].split(' ')]

    concat = "cat "
    for i in range(0, len(elements)):
        if   "Co" == str(elements[i]) :
            concat = concat + Co_POTCAR_file
        elif "Ni" == str(elements[i]) :
            concat = concat + Ni_POTCAR_file
        elif "Ti" == str(elements[i]) :
            concat = concat + Ti_POTCAR_file

    concat = concat + " > POTCAR"
    # concat = "cat " + Co_POTCAR_file + Ni_POTCAR_file + Ti_POTCAR_file +  " > POTCAR"

    print(concat)
    os.system(concat)

#*******************************************************************************
# this function creates toRunVasp/i folders
#*******************************************************************************
def createFolder_i(i):
        path = "toRunVasp/" + str(i)
        os.makedirs( path ) # create directory "i"

#*******************************************************************************
# this function just copy files into toRunVasp/i folder
#*******************************************************************************
def copyCARS(vaspFile, path,i):
        run = "cp myJob " +  path + "/"
        os.system(run)
        os.system("rm myJob")

        run = "cp " + vaspFile + "  " + path + "/POSCAR"
        # print(run)
        os.system(run)

        run = "cp POTCAR " +  path + "/"
        os.system(run)

        run = "cp INCAR "  + path + "/"
        os.system(run)

        run = "cp PRECALC " + path + "/"
        os.system(run)

        run = "cp getKPoints " + path + "/"
        os.system(run)

#*******************************************************************************
# this function deletes vasp.i file
#*******************************************************************************
def deleteVaspFile(i):
        run = "rm vasp." + str(i)
        os.system(run)


def getKPoints(path,i):
        run = "cd " + path + "; pwd; ./getKPoints ; cd ../.. "
        os.system(run)

def getJob(i):
        jobID = '\"vasp_' + str(i) + '\"'

        file = open ("myJob", "w")

        file.write("#!/bin/bash\n\n")
        file.write("#SBATCH --time=03:00:00   # walltime\n\n")
        file.write("#SBATCH --ntasks=1   # number of processor cores (i.e. tasks)\n\n")
        file.write("#SBATCH --nodes=1   # number of nodes\n\n")
        file.write("#SBATCH --mem-per-cpu=6144M   # memory per CPU core\n\n")
        file.write("#SBATCH -J " )
        # file.write(" \"job\"  ")
        file.write(jobID)
        file.write("# job name\n\n")
        file.write("#SBATCH -p physics\n\n")
        file.write("#SBATCH --mail-user=carlos.leon.chinchay@gmail.com #email address\n\n")
        file.write("#SBATCH --mail-type=FAIL\n\n")
        #file.write("# Set the max number of threads to use for programs using ")
        #file.write("OpenMP. Should be <= ppn. Does nothing if the program doesn't use OpenMP.\n")
        #file.write("export OMP_NUM_THREADS=$SLURM_CPUS_ON_NODE\n\n")
        file.write("# LOAD MODULES, INSERT CODE, AND RUN YOUR PROGRAMS HERE\n")
        file.write("module purge\n")
        file.write("module load compiler_intel/13.0.1\n")
        file.write("module load gdb/7.9.1\n")
        file.write("module load compiler_gnu/4.9.2\n")
        file.write("module load mpi/openmpi-1.8.4_gnu-4.9.2\n")
        #file.write("/fslhome/glh43/vasp")
        file.write("/fslhome/glh43/bin/vasp54s")

        file.close()


def getFolderNames():
    run = "cd toRunVasp; ls > folderNames.txt ; cp folderNames.txt ../ ; rm folderNames.txt"
    os.system(run)

    myFile = "folderNames.txt"

    # se removio la ultima linea proque estava el nombre del mismo archivo, ^^'
    readFile = open(myFile)
    lines = readFile.readlines()
    readFile.close()

    w = open(myFile,'w')
    w.writelines([item for item in lines[:-1]])
    w.close()


#*******************************************************************************
# Main
#*******************************************************************************

run = "./enum.x"
os.system(run)

fileName = "struct_enum.out"
nRandomSamples = 200
indexLines = chooseRandom(fileName, nRandomSamples)

for i in indexLines:
    # run = "python3 /Users/chinchay/Documents/2_codes/enumlib/aux_src/makeStr.py " + str(i) + " -species Co Ni Ti"
    #run = "python3 makeStr_1b.py " + str(i) + " -species Co Ni Ti"
    run = "python3 makeStr.py " + str(i) + " -species Co Ni Ti"
    os.system(run)

    path     = "toRunVasp/" + str(i)
    vaspFile = "vasp."  + str(i)

    createFolder_i(i)
    getJob(i) # create file "myJob"
    getPOTCAR(vaspFile)
    copyCARS(vaspFile,path,i)
    deleteVaspFile(i)
    getKPoints(path,i)

    getFolderNames()

    # os.chdir( str(i))
    # os.chdir("../")




run = "...end."
print(run)

